# Plan modular y estado de aceptación

| Fase | Estado al entregar | Próximo hito verificable |
| --- | --- | --- |
| 1. Base nativa | Código creado, sin compilar/verificar en teléfono | Compilación CI verde e instalación HOME |
| 2. Tres temas | Definiciones y composiciones iniciales programadas; fondos ilustrados | Comparar con capturas originales y ajustar posiciones |
| 3. Editor profesional | Editor rápido de titulares/reloj/fondo | Editor de capas con historial y drag & drop |
| 4. Colección completa | Pendiente | Añadir 17 layouts **distintos**, no recolores |
| 5. Widgets y animaciones | Host externo básico, reloj/batería y transición simple | Librería de 30 variantes y configuración individual |
| 6. Optimización y entrega | Pendiente | Pruebas reales S26 Ultra, estabilidad, firma de release |

## Criterios de aceptación

1. APK instalable: **pendiente de compilación CI**.
2. Selección como HOME: **código implementado, por verificar**.
3. Abrir apps compatibles: **código implementado, por verificar**.
4. Aplicar tema real: **código implementado, por verificar**.
5. Personalizar widgets/textos/iconos: **parcial** (texto, reloj, fondo; widget externo básico; personalización avanzada de iconos pendiente).
6. Guardar y recuperar diseño: **parcial** (guardado de ajustes, no editor libre).
7. Reiniciar dispositivo sin perder configuraciones: **persistencia programada, por verificar**.
8. Regresar a One UI Home: **acceso a ajustes implementado, por verificar**.
9. Características principales sin conexión: **diseñado para funcionamiento local** (excepto proveedores externos cuando se añadan).
10. Sin botones ficticios: **los controles expuestos en alpha1 tienen una acción programada**, pero se requiere prueba de dispositivo.

## Arquitectura futura

Mantener la distinción entre `data` (estado y catálogo de apps), `ui` (motor nativo HOME y layouts), `assets/themes` (configuración declarativa) y el motor de widgets. Migrar almacenamiento JSON a Room/DataStore con pruebas de migración que conserven perfiles; migrar componentes seleccionados a Compose, no el componente HOME sin plan de compatibilidad; cada tema nuevo deberá tener un layout propio probado.
