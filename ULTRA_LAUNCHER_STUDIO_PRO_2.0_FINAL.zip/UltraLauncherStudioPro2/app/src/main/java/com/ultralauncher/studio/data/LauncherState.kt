package com.ultralauncher.studio.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Versioned, local and transparent state. No remote services or tracking. */
class LauncherState(context: Context) {
    private val preferences = context.getSharedPreferences("launcher_state", Context.MODE_PRIVATE)
    private var document: JSONObject = try {
        JSONObject(preferences.getString("state", "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }

    var themeId: String
        get() = document.optString("theme", "coastal")
        set(value) = setString("theme", value)

    var animation: String
        get() = document.optString("animation", "subtle")
        set(value) = setString("animation", value)

    fun clockScale(themeId: String): Float = objectFor("clockScales").optDouble(themeId, 1.0).toFloat().coerceIn(0.65f, 1.4f)
    fun setClockScale(themeId: String, scale: Float) {
        objectFor("clockScales").put(themeId, scale.toDouble()); persist()
    }

    var pages: Int
        get() = document.optInt("pages", 3).coerceIn(1, 5)
        set(value) { document.put("pages", value.coerceIn(1, 5)); persist() }

    private fun objectFor(name: String): JSONObject {
        val existing = document.optJSONObject(name)
        if (existing != null) return existing
        return JSONObject().also { document.put(name, it) }
    }

    private fun setString(key: String, value: String) {
        document.put(key, value)
        persist()
    }

    fun headline(theme: ThemeDefinition): String = objectFor("headlines").optString(theme.id, theme.headline)
    fun setHeadline(themeId: String, value: String) {
        objectFor("headlines").put(themeId, value.take(40)); persist()
    }

    fun wallpaper(themeId: String): String? = objectFor("wallpapers").optString(themeId).takeIf { it.isNotBlank() }
    fun setWallpaper(themeId: String, uri: String) {
        objectFor("wallpapers").put(themeId, uri); persist()
    }
    fun clearWallpaper(themeId: String) { objectFor("wallpapers").remove(themeId); persist() }

    fun widget(themeId: String): Int = objectFor("widgets").optInt(themeId, -1)
    fun setWidget(themeId: String, id: Int) { objectFor("widgets").put(themeId, id); persist() }
    fun clearWidget(themeId: String) { objectFor("widgets").remove(themeId); persist() }

    private fun pageKey(themeId: String, page: Int) = "$themeId:$page"

    fun favorites(themeId: String, page: Int): List<String> {
        val array = objectFor("favorites").optJSONArray(pageKey(themeId, page)) ?: return emptyList()
        return (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
    }

    fun setFavorites(themeId: String, page: Int, apps: List<String>) {
        val items = JSONArray(); apps.distinct().take(30).forEach { items.put(it) }
        objectFor("favorites").put(pageKey(themeId, page), items); persist()
    }

    fun hasFavorites(themeId: String, page: Int): Boolean =
        objectFor("favorites").has(pageKey(themeId, page))

    data class Folder(val name: String, val apps: List<String>)

    fun folders(themeId: String, page: Int): List<Folder> {
        val array = objectFor("folders").optJSONArray(pageKey(themeId, page)) ?: return emptyList()
        return (0 until array.length()).mapNotNull { i ->
            val obj = array.optJSONObject(i) ?: return@mapNotNull null
            val applications = obj.optJSONArray("apps") ?: JSONArray()
            Folder(obj.optString("name", "Carpeta"),
                (0 until applications.length()).map { applications.optString(it) }.filter(String::isNotBlank))
        }
    }

    fun setFolders(themeId: String, page: Int, folders: List<Folder>) {
        val array = JSONArray()
        folders.take(15).forEach { folder ->
            val apps = JSONArray(); folder.apps.distinct().forEach { apps.put(it) }
            array.put(JSONObject().put("name", folder.name.take(32)).put("apps", apps))
        }
        objectFor("folders").put(pageKey(themeId, page), array); persist()
    }

    fun asJson(): String = JSONObject(document.toString()).apply {
        // Widget IDs belong to this installation and cannot be transferred.
        remove("widgets")
        put("format", "ultra-launcher-2")
        put("version", 1)
    }.toString(2)

    /** Validates before replacing; caller must obtain user's consent. */
    fun importJson(text: String) {
        val candidate = JSONObject(text)
        if (candidate.optString("format") != "ultra-launcher-2")
            throw IllegalArgumentException("Este archivo no es un perfil Ultra Launcher 2")
        if (candidate.optInt("version", 0) > 1)
            throw IllegalArgumentException("El perfil pertenece a una versión posterior")
        // Keep the live bindings of this installation, never trust imported IDs.
        candidate.remove("widgets")
        document.optJSONObject("widgets")?.let { candidate.put("widgets", it) }
        document = candidate
        persist()
    }

    fun persist() {
        document.put("format", "ultra-launcher-2")
        document.put("version", 1)
        preferences.edit().putString("state", document.toString()).apply()
    }
}
