package com.ultralauncher.studio.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable

/** Enumerates LAUNCHER activities via narrowly scoped package visibility. */
class AppCatalog(private val context: Context) {
    data class App(val label: String, val component: ComponentName, val icon: Drawable) {
        val key: String get() = component.flattenToString()
    }

    fun installed(): List<App> {
        val manager = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results: List<ResolveInfo> = if (android.os.Build.VERSION.SDK_INT >= 33) {
            manager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            manager.queryIntentActivities(intent, 0)
        }
        return results.mapNotNull { result ->
            val info = result.activityInfo ?: return@mapNotNull null
            try {
                App(result.loadLabel(manager).toString(),
                    ComponentName(info.packageName, info.name), result.loadIcon(manager))
            } catch (_: Exception) { null }
        }.distinctBy { it.key }.sortedBy { it.label.lowercase() }
    }

    fun launch(app: App): Boolean {
        return try {
            val intent = Intent.makeMainActivity(app.component).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) { false }
    }
}
