package com.ultralauncher.studio.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

internal fun Context.dp(n: Number): Int = (n.toFloat() * resources.displayMetrics.density + .5f).toInt()

internal fun shape(color: Int, radius: Float, stroke: Int? = null): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (stroke != null) setStroke(1, stroke)
    }

internal fun Context.vbox(gap: Int = 0): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    if (gap != 0) setPadding(dp(gap), dp(gap), dp(gap), dp(gap))
}

internal fun Context.hbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

internal fun Context.label(text: String, sp: Float = 14f, color: Int = Color.WHITE, heavy: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        includeFontPadding = false
        if (heavy) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        gravity = Gravity.CENTER_VERTICAL
    }

internal fun View.padding(horizontal: Int, vertical: Int = horizontal): View = apply {
    setPadding(context.dp(horizontal), context.dp(vertical), context.dp(horizontal), context.dp(vertical))
}

internal fun LinearLayout.add(view: View, width: Int = ViewGroup.LayoutParams.MATCH_PARENT,
                              height: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
                              weight: Float = 0f) {
    addView(view, LinearLayout.LayoutParams(width, height, weight))
}

internal fun Context.action(text: String, bg: Int = Color.argb(55, 255, 255, 255), fg: Int = Color.WHITE, onTap: () -> Unit): TextView =
    label(text, 13f, fg, true).apply {
        gravity = Gravity.CENTER
        background = shape(bg, dp(14).toFloat())
        setPadding(dp(12), dp(11), dp(12), dp(11))
        isClickable = true
        isFocusable = true
        setOnClickListener { onTap() }
    }
