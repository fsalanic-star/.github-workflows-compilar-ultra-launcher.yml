package com.ultralauncher.studio.data

import android.content.Context
import android.graphics.Color
import org.json.JSONObject

data class ThemeDefinition(
    val id: String,
    val name: String,
    val collection: String,
    val background: String,
    val style: String,
    val accent: Int,
    val text: Int,
    val description: String,
    val headline: String
)

object ThemeCatalog {
    private val themeFiles = listOf("coastal.json", "welcome.json", "artistic.json")
    fun load(context: Context): List<ThemeDefinition> = themeFiles.map { file ->
        val json = JSONObject(context.assets.open("themes/$file").bufferedReader().use { it.readText() })
        ThemeDefinition(
            json.getString("id"), json.getString("name"), json.getString("collection"),
            json.getString("background"), json.getString("style"),
            Color.parseColor(json.getString("accent")), Color.parseColor(json.getString("text")),
            json.getString("description"), json.getString("headline")
        )
    }
}
