package com.ultralauncher.studio.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.role.RoleManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.ultralauncher.studio.data.AppCatalog
import com.ultralauncher.studio.data.LauncherState
import com.ultralauncher.studio.data.ThemeCatalog
import com.ultralauncher.studio.data.ThemeDefinition
import java.text.SimpleDateFormat
import java.util.*

/** Real HOME activity. Pure Android Views to keep the first native phase dependency-light. */
class LauncherActivity : Activity() {
    private lateinit var store: LauncherState
    private lateinit var catalog: AppCatalog
    private lateinit var themes: List<ThemeDefinition>
    private lateinit var host: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager
    private var apps: List<AppCatalog.App> = emptyList()
    private var page = 0
    private var preview: String? = null
    private var inDrawer = false
    private var pendingWidget = -1
    private var pendingWidgetTheme = ""
    private var requestedWallpaperTheme = ""
    private var clockViews = mutableListOf<TextView>()
    private var drawerSearch: EditText? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private val clockTick = object : Runnable {
        override fun run() {
            val value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            clockViews.forEach { it.text = value }
            uiHandler.postDelayed(this, 15000L)
        }
    }

    private lateinit var gestures: GestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingWidget = savedInstanceState?.getInt("pendingWidget", -1) ?: -1
        pendingWidgetTheme = savedInstanceState?.getString("pendingWidgetTheme") ?: ""
        requestedWallpaperTheme = savedInstanceState?.getString("wallpaperTheme") ?: ""
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        store = LauncherState(this)
        catalog = AppCatalog(this)
        themes = ThemeCatalog.load(this)
        host = AppWidgetHost(this, 4407)
        widgetManager = AppWidgetManager.getInstance(this)
        apps = catalog.installed()
        seedFavorites()
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(event: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (inDrawer || e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (kotlin.math.abs(dx) > dp(80) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.2f) {
                    page = (page + if (dx < 0) 1 else -1).coerceIn(0, store.pages - 1)
                    renderHome()
                    return true
                }
                if (dy < -dp(85) && kotlin.math.abs(dy) > kotlin.math.abs(dx)) {
                    showDrawer(); return true
                }
                return false
            }
        })
        renderHome()
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(0) { handleBack() }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt("pendingWidget", pendingWidget)
        outState.putString("pendingWidgetTheme", pendingWidgetTheme)
        outState.putString("wallpaperTheme", requestedWallpaperTheme)
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        preview = null
        page = 0
        renderHome()
    }

    @Suppress("DEPRECATION")
    private fun safeInsets(insets: WindowInsets): Rect =
        if (Build.VERSION.SDK_INT >= 30) {
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            Rect(bars.left, bars.top, bars.right, bars.bottom)
        } else Rect(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
            insets.systemWindowInsetRight, insets.systemWindowInsetBottom)

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        val handled = if (::gestures.isInitialized) gestures.onTouchEvent(event) else false
        if (event.actionMasked == MotionEvent.ACTION_UP && handled && !inDrawer) return true
        return super.dispatchTouchEvent(event)
    }

    override fun onStart() { super.onStart(); try { host.startListening() } catch (_: Exception) {} }
    override fun onStop() { try { host.stopListening() } catch (_: Exception) {}; super.onStop() }
    override fun onResume() {
        super.onResume()
        val current = catalog.installed()
        if (current.map { it.key } != apps.map { it.key }) {
            apps = current
            if (::store.isInitialized) seedFavorites()
            if (!inDrawer) renderHome() else showDrawer()
        }
        uiHandler.removeCallbacks(clockTick)
        uiHandler.post(clockTick)
    }
    override fun onPause() { uiHandler.removeCallbacks(clockTick); super.onPause() }
    override fun onDestroy() { uiHandler.removeCallbacks(clockTick); super.onDestroy() }

    @Deprecated("Legacy activity results retained so Phase 1 can compile without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_WALLPAPER -> if (resultCode == RESULT_OK) {
                data?.data?.let { uri ->
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) {}
                    store.setWallpaper(requestedWallpaperTheme, uri.toString())
                    renderHome()
                }
            }
            REQ_PICK_WIDGET -> {
                if (resultCode == RESULT_OK) {
                    val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget) ?: pendingWidget
                    val info = widgetManager.getAppWidgetInfo(id)
                    val provider = info?.provider ?: run {
                        if (Build.VERSION.SDK_INT >= 33) {
                            data?.getParcelableExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, ComponentName::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            data?.getParcelableExtra<ComponentName>(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER)
                        }
                    }
                    if (provider != null) bindWidget(id, provider)
                    else { releaseWidget(id); message("El widget seleccionado no está disponible") }
                } else releaseWidget(pendingWidget)
            }
            REQ_BIND_WIDGET -> if (resultCode == RESULT_OK) finishWidgetBinding(pendingWidget)
                else releaseWidget(pendingWidget)
            REQ_CONFIG_WIDGET -> if (resultCode == RESULT_OK) saveWidget(pendingWidget)
                else releaseWidget(pendingWidget)
            REQ_EXPORT -> if (resultCode == RESULT_OK) {
                data?.data?.let { uri ->
                    try {
                        contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.asJson()) }
                        message("Perfil exportado")
                    } catch (error: Exception) { message("No fue posible exportar: ${error.localizedMessage}") }
                }
            }
            REQ_IMPORT -> if (resultCode == RESULT_OK) {
                data?.data?.let { uri ->
                    try {
                        val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Archivo vacío")
                        AlertDialog.Builder(this).setTitle("Importar configuración")
                            .setMessage("Esto reemplazará la configuración local actual. ¿Continuar?")
                            .setNegativeButton("Cancelar", null)
                            .setPositiveButton("Importar") { _, _ ->
                                try { store.importJson(text); page = 0; renderHome(); message("Importado") }
                                catch (e: Exception) { message(e.localizedMessage ?: "Error importando") }
                            }.show()
                    } catch (e: Exception) { message(e.localizedMessage ?: "No se pudo leer el archivo") }
                }
            }
            REQ_ROLE_HOME -> message(if (isDefaultHome()) "Ultra Launcher es tu inicio" else "Puedes elegir el inicio en Ajustes")
        }
    }

    private fun isDefaultHome(): Boolean {
        val role = getSystemService(RoleManager::class.java)
        return role?.isRoleHeld(RoleManager.ROLE_HOME) == true
    }

    private fun requestHomeRole() {
        val role = getSystemService(RoleManager::class.java)
        if (role?.isRoleAvailable(RoleManager.ROLE_HOME) == true) {
            startActivityForResult(role.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE_HOME)
        } else openHomeSettings()
    }

    private fun openHomeSettings() {
        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        catch (_: Exception) { message("Ajustes → Aplicaciones → Aplicaciones predeterminadas → Aplicación de inicio") }
    }

    private fun theme(): ThemeDefinition = themes.firstOrNull { it.id == (preview ?: store.themeId) } ?: themes.first()
    private fun app(key: String): AppCatalog.App? = apps.firstOrNull { it.key == key }
    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun seedFavorites() {
        for (t in themes) {
            if (!store.hasFavorites(t.id, 0)) {
                val wanted = listOf("camera", "chrome", "settings", "gallery", "photos", "maps", "youtube", "messages")
                val chosen = wanted.mapNotNull { key ->
                    apps.firstOrNull { it.component.packageName.contains(key, true) }?.key
                }.distinct().take(8)
                store.setFavorites(t.id, 0, (chosen + apps.map { it.key }).distinct().take(8))
            }
        }
    }

    private fun background(theme: ThemeDefinition): FrameLayout {
        val base = FrameLayout(this)
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val uri = store.wallpaper(theme.id)
            if (uri != null) {
                try {
                    // Image picker is SAF based. The original user photo is never changed.
                    val imageUri = Uri.parse(uri)
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(imageUri)?.use {
                        BitmapFactory.decodeStream(it, null, opts)
                    }
                    opts.inSampleSize = 1
                    while (opts.outWidth / opts.inSampleSize > 1800 || opts.outHeight / opts.inSampleSize > 3200)
                        opts.inSampleSize *= 2
                    opts.inJustDecodeBounds = false
                    val bitmap = contentResolver.openInputStream(imageUri)?.use {
                        BitmapFactory.decodeStream(it, null, opts)
                    }
                    if (bitmap != null) setImageBitmap(bitmap) else setImageResource(themeBackground(theme))
                } catch (_: Exception) { setImageResource(themeBackground(theme)) }
            } else setImageResource(themeBackground(theme))
        }
        base.addView(photo, FrameLayout.LayoutParams(-1, -1))
        val shade = when (theme.id) {
            "coastal" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x50041620, 0x18051219, 0xAD000C11.toInt()))
            "welcome" -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x49000000, 0x10000000, 0xEB0A0D14.toInt()))
            else -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x0AFFFFFF, 0x13FFFFFF, 0x260A1314))
        }
        base.addView(View(this).apply { background = shade }, FrameLayout.LayoutParams(-1, -1))
        return base
    }

    private fun themeBackground(t: ThemeDefinition): Int = resources.getIdentifier(t.background, "drawable", packageName)

    private fun renderHome() {
        inDrawer = false
        clockViews.clear()
        val t = theme()
        val frame = background(t)
        val content = vbox().apply {
            setPadding(dp(19), dp(14), dp(19), dp(16))
            isLongClickable = true
            setOnLongClickListener { showHomeMenu(); true }
        }
        val onDark = if (t.id == "artistic") 0xFF20211F.toInt() else Color.WHITE
        val top = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        top.add(action("☰", if (t.id == "artistic") 0x55FFFFFF else 0x55000000, onDark) { showHomeMenu() }, dp(52), dp(44))
        top.addView(View(this@LauncherActivity), LinearLayout.LayoutParams(0, 1, 1f))
        top.add(action(if (preview != null) "VISTA PREVIA" else t.name.uppercase(),
            if (t.id == "artistic") 0x66FFFFFF else 0x44000000, onDark) { themeChooser() }, -2, dp(44))
        content.add(top)
        when (t.style) {
            "coastal" -> coastalHeader(content, t)
            "welcome" -> welcomeHeader(content, t)
            else -> artisticHeader(content, t)
        }
        content.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        if (t.style == "welcome" && page == 0) welcomeInfoPanel(content)
        if (page == 0) renderHostWidget(content, t)
        if (page > 0) content.add(label("ESCRITORIO ${page + 1}", 13f, onDark, true).padding(0, 10))
        renderShortcuts(content, t)
        renderFolders(content, t)
        val pageNav = hbox().apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(9)) }
        repeat(store.pages) { idx ->
            pageNav.add(label(if (idx == page) "●" else "○", 19f, onDark).apply {
                setPadding(dp(5), 0, dp(5), 0)
                setOnClickListener { page = idx; renderHome() }
            }, -2, -2)
        }
        content.add(pageNav)
        renderDock(content, t)
        content.add(action("⌃  TODAS LAS APLICACIONES", 0x38000000, onDark) { showDrawer() }.apply {
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }, -1, -2)
        if (preview != null) {
            val banner = hbox().apply { setPadding(0, dp(8), 0, 0) }
            banner.add(action("VOLVER", 0xAA222222.toInt()) { preview = null; renderHome() }, 0, dp(43), 1f)
            banner.add(action("APLICAR", 0xFF33564F.toInt()) { applyTheme(t.id) }, 0, dp(43), 1f)
            content.add(banner)
        }
        frame.addView(content, FrameLayout.LayoutParams(-1, -1))
        frame.setOnApplyWindowInsetsListener { view, insets ->
            val bars = safeInsets(insets)
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(frame)
        when (store.animation) {
            "subtle" -> content.apply { alpha = 0.5f; animate().alpha(1f).setDuration(180).start() }
            "balanced" -> content.apply {
                alpha = 0f; translationY = dp(16).toFloat()
                animate().alpha(1f).translationY(0f).setDuration(280).start()
            }
        }
    }

    private fun makeClock(size: Float, color: Int): TextView = label("", size * store.clockScale(theme().id), color, true).apply {
        setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL))
        clockViews.add(this)
        text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }
    private fun currentDate(): String = SimpleDateFormat("EEEE  dd MMMM", Locale.getDefault()).format(Date()).uppercase()
    private fun battery(): Int {
        val data = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = data?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = data?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) level * 100 / scale else -1
    }

    private fun coastalHeader(body: LinearLayout, t: ThemeDefinition) {
        val h = hbox().apply { setPadding(0, dp(25), 0, dp(4)) }
        h.addView(label(store.headline(t).uppercase().toList().joinToString("\n"), 33f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = -.1f
        }, LinearLayout.LayoutParams(dp(63), dp(245)))
        val right = vbox().apply { gravity = Gravity.END; setPadding(dp(8), dp(8), 0, 0) }
        right.add(label("ULTRA  /  EDITION  01", 11f, 0xFFDFE5DF.toInt(), true))
        right.add(makeClock(52f, Color.WHITE))
        right.add(label(currentDate(), 12f, Color.WHITE, true))
        right.add(label("EL CLIMA REQUIERE PROVEEDOR", 10f, 0xFFE2E6E0.toInt()).padding(0, 9))
        h.add(right, 0, -1, 1f)
        body.add(h)
    }

    private fun welcomeHeader(body: LinearLayout, t: ThemeDefinition) {
        body.add(label(store.headline(t).uppercase(), 53f, Color.WHITE, true).apply {
            letterSpacing = -.06f
            setPadding(0, dp(17), 0, 0)
        })
        body.add(label("CURATED SPACE   •   VOL. 02", 10f, 0xFFD9D5D0.toInt(), true))
    }

    private fun welcomeInfoPanel(body: LinearLayout) {
        val info = vbox().apply {
            background = shape(0xD80B111B.toInt(), dp(21).toFloat())
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        info.add(label("TODAY  /  ${currentDate()}", 12f, 0xFFEBE5E0.toInt()))
        val row = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        row.add(makeClock(45f, Color.WHITE), 0, -2, 1f)
        val b = battery()
        row.add(label(if (b >= 0) "BATERÍA $b%" else "BATERÍA N/D", 11f, 0xFFD1D7D7.toInt(), true))
        info.add(row)
        body.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun artisticHeader(body: LinearLayout, t: ThemeDefinition) {
        body.add(label("S T U D I O   /   0 3", 12f, 0xFF242424.toInt(), true).padding(0, 18))
        body.add(label(store.headline(t).uppercase(), 53f, 0xFF242321.toInt(), true).apply {
            letterSpacing = -.08f
        })
        body.add(label("EVERY DAY IS A BLANK CANVAS", 11f, 0xFF242321.toInt(), true))
        val panel = vbox().apply {
            background = shape(0xDDFFF5E4.toInt(), dp(22).toFloat())
            setPadding(dp(17), dp(14), dp(17), dp(15))
        }
        val row = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        row.add(makeClock(43f, 0xFF1F201D.toInt()), 0, -2, 1f)
        row.add(label("●  ${battery().takeIf { it >= 0 }?.let { "$it%" } ?: "N/D"}", 12f, 0xFFB55C2E.toInt(), true))
        panel.add(row)
        panel.add(label(currentDate(), 11f, 0xFF514840.toInt()))
        body.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
    }

    private fun renderShortcuts(body: LinearLayout, t: ThemeDefinition) {
        val items = store.favorites(t.id, page).mapNotNull(::app).take(16)
        val grid = GridLayout(this).apply {
            columnCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        val itemWidth = (resources.displayMetrics.widthPixels - dp(48)) / 4
        items.forEachIndexed { idx, entry ->
            val cell = vbox().apply {
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(6))
                isClickable = true
                if (t.id == "artistic") translationY = dp(intArrayOf(0, 10, -5, 14)[idx % 4]).toFloat()
                setOnClickListener { openApp(entry) }
                setOnLongClickListener { showAppActions(entry); true }
            }
            val bubble = FrameLayout(this).apply {
                background = when (t.id) {
                    "artistic" -> shape(0xCCFFF1DE.toInt(), dp(19).toFloat())
                    "welcome" -> shape(0x99202632.toInt(), dp(17).toFloat())
                    else -> shape(0x55FFFFFF, dp(18).toFloat(), 0x46FFFFFF)
                }
            }
            val icon = ImageView(this).apply { setImageDrawable(entry.icon.constantState?.newDrawable()?.mutate() ?: entry.icon) }
            val iconParams = FrameLayout.LayoutParams(dp(37), dp(37), Gravity.CENTER)
            bubble.addView(icon, iconParams)
            cell.add(bubble, dp(if (t.id == "artistic") 52 else 58), dp(if (t.id == "artistic") 52 else 58))
            cell.add(label(entry.label.take(14), 10.5f,
                if (t.id == "artistic") 0xFF211E1C.toInt() else Color.WHITE).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(7), 0, 0)
            })
            grid.addView(cell, GridLayout.LayoutParams(GridLayout.spec(idx / 4), GridLayout.spec(idx % 4)).apply {
                width = itemWidth; height = dp(92)
            })
        }
        body.add(grid)
    }

    private fun renderFolders(body: LinearLayout, t: ThemeDefinition) {
        val folders = store.folders(t.id, page)
        if (folders.isEmpty()) return
        val bar = hbox().apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(3)) }
        folders.forEachIndexed { index, folder ->
            val color = if (t.id == "artistic") 0xFF1A2421.toInt() else Color.WHITE
            bar.add(action("▦  ${folder.name}", if (t.id == "artistic") 0xAFFFF3DF.toInt() else 0x9A222A2A.toInt(), color) { openFolder(folder) }, 0, dp(48), 1f)
            if (index < folders.lastIndex) bar.addView(View(this), LinearLayout.LayoutParams(dp(6), 1))
        }
        body.add(bar)
    }

    private fun dockApps(): List<AppCatalog.App> {
        val priorities = listOf("dialer", "phone", "messages", "chrome", "camera", "settings")
        val pinned = priorities.mapNotNull { key -> apps.firstOrNull { it.component.packageName.contains(key, true) } }
        return (pinned + apps).distinctBy { it.key }.take(4)
    }

    private fun renderDock(body: LinearLayout, t: ThemeDefinition) {
        val dock = hbox().apply {
            gravity = Gravity.CENTER
            background = shape(if (t.id == "artistic") 0xC8FFE8D1.toInt() else 0x9910141A.toInt(), dp(23).toFloat())
            setPadding(dp(7), dp(8), dp(7), dp(8))
        }
        for (entry in dockApps()) {
            val holder = FrameLayout(this).apply {
                isClickable = true
                setOnClickListener { openApp(entry) }
                setOnLongClickListener { showAppActions(entry); true }
                contentDescription = "Abrir ${entry.label}"
            }
            holder.addView(ImageView(this).apply {
                setImageDrawable(entry.icon.constantState?.newDrawable()?.mutate() ?: entry.icon)
            }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            dock.addView(holder, LinearLayout.LayoutParams(0, dp(54), 1f))
        }
        body.addView(dock, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun openApp(entry: AppCatalog.App) {
        if (!catalog.launch(entry)) message("No se pudo abrir ${entry.label}. La aplicación puede estar deshabilitada.")
    }

    private fun showAppActions(entry: AppCatalog.App) {
        val options = arrayOf("Abrir", "Añadir al escritorio ${page + 1}", "Mover a otro escritorio", "Quitar de este escritorio")
        AlertDialog.Builder(this).setTitle(entry.label).setItems(options) { _, selected ->
            when (selected) {
                0 -> openApp(entry)
                1 -> addFavorite(entry)
                2 -> {
                    val names = Array(store.pages) { "Escritorio ${it + 1}" }
                    AlertDialog.Builder(this).setTitle("Mover icono a")
                        .setItems(names) { _, target ->
                            val origin = store.favorites(theme().id, page).toMutableList()
                            origin.remove(entry.key); store.setFavorites(theme().id, page, origin)
                            val dest = store.favorites(theme().id, target).toMutableList()
                            if (entry.key !in dest) dest.add(entry.key)
                            store.setFavorites(theme().id, target, dest)
                            renderHome()
                        }.show()
                }
                3 -> {
                    store.setFavorites(theme().id, page, store.favorites(theme().id, page).filterNot { it == entry.key })
                    renderHome()
                }
            }
        }.show()
    }

    private fun addFavorite(entry: AppCatalog.App) {
        val values = store.favorites(theme().id, page).toMutableList()
        if (entry.key !in values) {
            values.add(entry.key)
            store.setFavorites(theme().id, page, values)
        }
        renderHome()
    }

    private fun openFolder(folder: LauncherState.Folder) {
        val entries = folder.apps.mapNotNull(::app)
        AlertDialog.Builder(this).setTitle(folder.name)
            .setItems(entries.map { it.label }.toTypedArray()) { _, index -> openApp(entries[index]) }
            .setNeutralButton("Eliminar carpeta") { _, _ ->
                AlertDialog.Builder(this).setTitle("Eliminar ${folder.name}")
                    .setMessage("Las aplicaciones no se desinstalarán.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Eliminar") { _, _ ->
                        val folders = store.folders(theme().id, page).toMutableList()
                        folders.remove(folder)
                        store.setFolders(theme().id, page, folders)
                        renderHome()
                    }.show()
            }.setNegativeButton("Cerrar", null).show()
    }

    private fun createFolder() {
        val name = EditText(this).apply { setSingleLine(); hint = "Nombre de la carpeta" }
        AlertDialog.Builder(this).setTitle("Nueva carpeta").setView(name)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Elegir aplicaciones") { _, _ ->
                val chosen = BooleanArray(apps.size)
                val labels = apps.map { it.label }.toTypedArray()
                AlertDialog.Builder(this).setTitle("Selecciona las aplicaciones")
                    .setMultiChoiceItems(labels, chosen) { _, i, selected -> chosen[i] = selected }
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Crear") { _, _ ->
                        val selected = apps.filterIndexed { idx, _ -> chosen[idx] }.map { it.key }
                        if (selected.isEmpty()) { message("Selecciona al menos una aplicación"); return@setPositiveButton }
                        val all = store.folders(theme().id, page).toMutableList()
                        all.add(LauncherState.Folder(name.text.toString().trim().ifBlank { "Carpeta" }, selected))
                        store.setFolders(theme().id, page, all)
                        renderHome()
                    }.show()
            }.show()
    }

    private fun showDrawer() {
        inDrawer = true
        clockViews.clear()
        val t = theme()
        val dark = 0xFF101318.toInt()
        val root = vbox().apply { setBackgroundColor(dark); setPadding(dp(17), dp(20), dp(17), dp(12)) }
        val top = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        top.add(label("APLICACIONES", 23f, Color.WHITE, true), 0, -2, 1f)
        top.add(action("CERRAR  ×", 0xFF292D32.toInt()) { renderHome() })
        root.add(top)
        val search = EditText(this).apply {
            hint = "Buscar aplicaciones instaladas"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9CA6A9.toInt())
            background = shape(0xFF22272E.toInt(), dp(18).toFloat())
            setPadding(dp(17), dp(14), dp(17), dp(14))
        }
        drawerSearch = search
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(22); bottomMargin = dp(16)
        })
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val list = GridLayout(this).apply { columnCount = 4 }
        scroll.addView(list)
        root.add(scroll, -1, 0, 1f)
        fun populate(query: String) {
            list.removeAllViews()
            val visible = apps.filter { it.label.contains(query, ignoreCase = true) }
            val cellWidth = (resources.displayMetrics.widthPixels - dp(34)) / 4
            visible.forEachIndexed { idx, entry ->
                val cell = vbox().apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(3), dp(9), dp(3), dp(10))
                    setOnClickListener { openApp(entry) }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@LauncherActivity).setTitle(entry.label)
                            .setItems(arrayOf("Abrir", "Añadir a escritorio ${page + 1}")) { _, option ->
                                if (option == 0) openApp(entry) else addFavorite(entry)
                            }.show()
                        true
                    }
                }
                cell.add(ImageView(this).apply {
                    setImageDrawable(entry.icon.constantState?.newDrawable()?.mutate() ?: entry.icon)
                }, dp(47), dp(47))
                cell.add(label(entry.label, 10.5f, 0xFFE0E4E7.toInt()).apply {
                    gravity = Gravity.CENTER; maxLines = 2
                }.padding(0, 9))
                list.addView(cell, GridLayout.LayoutParams(GridLayout.spec(idx / 4), GridLayout.spec(idx % 4)).apply {
                    width = cellWidth; height = dp(102)
                })
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        populate("")
        root.setOnApplyWindowInsetsListener { view, insets ->
            val bars = safeInsets(insets)
            view.setPadding(bars.left + dp(17), bars.top + dp(20), bars.right + dp(17), bars.bottom + dp(12))
            insets
        }
        setContentView(root)
    }

    private fun showHomeMenu() {
        val options = arrayOf(
            "Explorar 3 temas", "Añadir aplicación", "Crear carpeta", "Añadir widget Android",
            "Elegir foto de fondo", "Restaurar fondo del tema", "Editor rápido de texto",
            "Configurar escritorios", "Exportar perfil", "Importar perfil", "Elegir como inicio predeterminado",
            "Volver a One UI Home", "Rendimiento y opciones"
        )
        AlertDialog.Builder(this).setTitle("HOME STUDIO  ·  ULTRA 2.0")
            .setItems(options) { _, which -> when (which) {
                0 -> themeChooser()
                1 -> chooseApp()
                2 -> createFolder()
                3 -> pickWidget()
                4 -> pickWallpaper()
                5 -> { store.clearWallpaper(theme().id); renderHome() }
                6 -> themeEditor(theme().id)
                7 -> configureDesktops()
                8 -> exportProfile()
                9 -> importProfile()
                10 -> requestHomeRole()
                11 -> openHomeSettings()
                12 -> settings()
            }}.show()
    }

    private fun chooseApp() {
        val names = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Agregar aplicación al escritorio ${page + 1}")
            .setItems(names) { _, i -> addFavorite(apps[i]) }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun themeChooser() {
        val names = themes.map { "${it.name}  —  ${it.description}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("EXPLORE  ·  Temas disponibles")
            .setItems(names) { _, choice ->
                val selected = themes[choice]
                AlertDialog.Builder(this).setTitle(selected.name)
                    .setMessage(selected.description)
                    .setPositiveButton("APLICAR") { _, _ -> applyTheme(selected.id) }
                    .setNeutralButton("PERSONALIZAR") { _, _ -> themeEditor(selected.id) }
                    .setNegativeButton("PREVISUALIZAR") { _, _ ->
                        preview = selected.id; page = 0; renderHome()
                    }.show()
            }.setNegativeButton("Cerrar", null).show()
    }

    private fun applyTheme(themeId: String) {
        store.themeId = themeId
        preview = null
        page = 0
        renderHome()
        message("Tema aplicado a la pantalla de inicio")
    }

    private fun themeEditor(themeId: String) {
        AlertDialog.Builder(this).setTitle("THEME EDITOR · PERSONALIZACIÓN")
            .setItems(arrayOf("Editar titular del tema", "Cambiar tamaño del reloj", "Cambiar fotografía de fondo")) { _, index ->
                when (index) {
                    0 -> customize(themeId)
                    1 -> editClockScale(themeId)
                    2 -> { preview = themeId; pickWallpaper() }
                }
            }.show()
    }

    private fun editClockScale(themeId: String) {
        val seek = SeekBar(this).apply {
            max = 75; progress = ((store.clockScale(themeId) - 0.65f) * 100).toInt().coerceIn(0, 75)
            setPadding(dp(22), dp(20), dp(22), dp(20))
        }
        AlertDialog.Builder(this).setTitle("Tamaño del reloj  ·  65%–140%")
            .setView(seek)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("GUARDAR") { _, _ ->
                store.setClockScale(themeId, 0.65f + seek.progress / 100f)
                preview = themeId; renderHome()
            }.show()
    }

    private fun customize(themeId: String) {
        val t = themes.firstOrNull { it.id == themeId } ?: return
        val editor = EditText(this).apply {
            setSingleLine(true)
            setText(store.headline(t))
            hint = "Título editorial"
            setSelection(text.length)
        }
        AlertDialog.Builder(this).setTitle("THEME EDITOR · ${t.name}")
            .setMessage("Edita el título de la composición. El cambio se guarda en este tema.")
            .setView(editor)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("GUARDAR") { _, _ ->
                store.setHeadline(themeId, editor.text.toString())
                preview = themeId
                renderHome()
            }.show()
    }

    private fun configureDesktops() {
        val options = Array(5) { "${it + 1} escritorio${if (it == 0) "" else "s"}" }
        AlertDialog.Builder(this).setTitle("Cantidad de escritorios")
            .setSingleChoiceItems(options, store.pages - 1) { dialog, which ->
                store.pages = which + 1
                page = page.coerceAtMost(store.pages - 1)
                dialog.dismiss(); renderHome()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun settings() {
        val options = arrayOf("Animaciones: ${store.animation}",
            "Configurar como launcher predeterminado", "Volver a One UI Home",
            "Aplicaciones visibles: ${apps.size}", "Exportar mis perfiles", "Importar perfiles")
        AlertDialog.Builder(this).setTitle("SETTINGS  ·  Control y seguridad")
            .setItems(options) { _, index -> when (index) {
                0 -> AlertDialog.Builder(this).setTitle("Perfil de animación")
                    .setItems(arrayOf("Desactivadas", "Sutiles", "Equilibradas")) { _, i ->
                        store.animation = listOf("off", "subtle", "balanced")[i]
                        renderHome()
                    }.show()
                1 -> requestHomeRole()
                2 -> openHomeSettings()
                3 -> showDrawer()
                4 -> exportProfile()
                5 -> importProfile()
            }}.show()
    }

    private fun pickWallpaper() {
        requestedWallpaperTheme = theme().id
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_WALLPAPER)
    }

    private fun exportProfile() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "ultra-launcher-2-backup.json")
        }, REQ_EXPORT)
    }

    private fun importProfile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }, REQ_IMPORT)
    }

    private fun renderHostWidget(body: LinearLayout, t: ThemeDefinition) {
        val widgetId = store.widget(t.id)
        if (widgetId < 0) return
        val provider = widgetManager.getAppWidgetInfo(widgetId)
        if (provider == null) {
            body.add(action("Widget no disponible · tocar para quitar", 0xBB222222.toInt()) {
                store.clearWidget(t.id); releaseWidget(widgetId); renderHome()
            })
            return
        }
        try {
            val widget = host.createView(this, widgetId, provider)
            body.addView(widget, LinearLayout.LayoutParams(-1, dp(136)).apply { bottomMargin = dp(6) })
        } catch (_: Exception) {
            body.add(action("No se pudo cargar el widget · quitar", 0xBB222222.toInt()) {
                store.clearWidget(t.id); releaseWidget(widgetId); renderHome()
            })
        }
    }

    private fun pickWidget() {
        pendingWidgetTheme = theme().id
        pendingWidget = host.allocateAppWidgetId()
        try {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget)
            }
            startActivityForResult(intent, REQ_PICK_WIDGET)
        } catch (_: Exception) {
            releaseWidget(pendingWidget)
            message("No hay un selector de widgets compatible en este dispositivo")
        }
    }

    private fun bindWidget(id: Int, provider: ComponentName) {
        pendingWidget = id
        try {
            if (widgetManager.getAppWidgetInfo(id) != null || widgetManager.bindAppWidgetIdIfAllowed(id, provider)) finishWidgetBinding(id)
            else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider)
            }, REQ_BIND_WIDGET)
        } catch (_: Exception) { releaseWidget(id); message("No se pudo autorizar el widget") }
    }

    private fun finishWidgetBinding(id: Int) {
        val provider = widgetManager.getAppWidgetInfo(id) ?: run { releaseWidget(id); return }
        if (provider.configure == null) saveWidget(id)
        else {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG_WIDGET, null) }
            catch (_: Exception) { releaseWidget(id); message("El widget no se pudo configurar") }
        }
    }

    private fun saveWidget(id: Int) {
        val previous = store.widget(pendingWidgetTheme)
        if (previous >= 0 && previous != id) releaseWidget(previous)
        store.setWidget(pendingWidgetTheme, id)
        pendingWidget = -1
        renderHome()
    }

    private fun releaseWidget(id: Int) {
        if (id >= 0) try { host.deleteAppWidgetId(id) } catch (_: Exception) {}
        if (id == pendingWidget) pendingWidget = -1
    }

    @Deprecated("Back key supported for launcher drawer")
    override fun onBackPressed() {
        handleBack()
    }

    private fun handleBack() {
        if (inDrawer || preview != null) { preview = null; renderHome() }
        else if (page != 0) { page = 0; renderHome() }
        else { /* HOME is the root of the navigation stack; never exit accidentally. */ }
    }

    companion object {
        private const val REQ_ROLE_HOME = 10
        private const val REQ_WALLPAPER = 11
        private const val REQ_PICK_WIDGET = 12
        private const val REQ_BIND_WIDGET = 13
        private const val REQ_CONFIG_WIDGET = 14
        private const val REQ_EXPORT = 15
        private const val REQ_IMPORT = 16
    }
}
