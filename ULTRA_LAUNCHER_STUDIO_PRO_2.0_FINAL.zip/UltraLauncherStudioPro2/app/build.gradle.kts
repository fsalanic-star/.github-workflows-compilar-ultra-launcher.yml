plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ultralauncher.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ultralauncher.studio"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0-alpha2"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}
