import json
import pathlib
import unittest
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parent.parent
A = '{http://schemas.android.com/apk/res/android}'

class ProjectStructure(unittest.TestCase):
    def test_home_manifest(self):
        doc = ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
        cats = [c.attrib.get(A+'name') for c in doc.iter('category')]
        self.assertIn('android.intent.category.HOME', cats)
        self.assertIn('android.intent.category.LAUNCHER', cats)
        permissions = [p.attrib.get(A+'name') for p in doc.iter('uses-permission')]
        self.assertNotIn('android.permission.QUERY_ALL_PACKAGES', permissions)
        self.assertNotIn('android.permission.INTERNET', permissions)

    def test_three_distinct_theme_files(self):
        path = ROOT/'app/src/main/assets/themes'
        themes = [json.loads(p.read_text()) for p in sorted(path.glob('*.json'))]
        self.assertEqual(3, len(themes))
        self.assertEqual(3, len({t['style'] for t in themes}))
        for t in themes:
            self.assertTrue((ROOT/f'app/src/main/res/drawable-nodpi/{t["background"]}.jpg').is_file())

    def test_build_workflow(self):
        text = (ROOT/'.github/workflows/build-apk.yml').read_text()
        self.assertIn('assembleDebug', text)
        self.assertIn('upload-artifact', text)

if __name__ == '__main__':
    unittest.main()
