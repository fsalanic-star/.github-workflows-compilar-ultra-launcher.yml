# ULTRA LAUNCHER STUDIO PRO 2.0

**Versión entregada:** `2.0.0-alpha1` · Proyecto **Android nativo en Kotlin**. No es una WebView ni un simulador web.

> **Estado honesto:** se entrega el código fuente de un prototipo funcional de las fases 1 y 2, pendiente de compilación y validación con un dispositivo Samsung Galaxy S26 Ultra real. Este paquete **NO contiene una APK compilada**. No se ha probado físicamente y no puede afirmarse que cumpla los diez criterios de aceptación todavía.

## Funciones programadas (pendientes de prueba en teléfono)

- Registro de una `Activity` como `HOME`, elección del launcher con `RoleManager.ROLE_HOME` o ajustes oficiales y regreso a One UI Home.
- Descubrimiento limitado de actividades `MAIN`/`LAUNCHER` mediante `<queries>` y apertura por `ComponentName`, sin pedir `QUERY_ALL_PACKAGES`.
- Cajón de aplicaciones reales, filtro de búsqueda, accesos directos a actividades instaladas, dock y escritorios 1–5 con navegación por gestos y puntos.
- Carpetas con nombre, selección de apps, apertura y eliminación; mover/quitar/añadir apps de escritorios sin desinstalarlas.
- Tres temas declarativos independientes: Coastal Editorial, Welcome Pro y Artistic Aesthetic. Botones `PREVISUALIZAR`, `PERSONALIZAR`, `APLICAR`. Sus fondos incluidos son **ilustraciones originales de referencia**, no fotografías idénticas a las imágenes del usuario.
- Editor rápido funcional: título por tema, escala de reloj por tema, foto propia de fondo seleccionada mediante Android Storage Access Framework.
- Hora y fecha reales; porcentaje de batería proveniente de `ACTION_BATTERY_CHANGED`; se declara que el clima requiere un proveedor en vez de inventar información.
- Un widget Android externo por tema, alojado mediante `AppWidgetHost` (requiere comprobación práctica del selector, binding y configuración en One UI).
- Configuraciones locales mediante `SharedPreferences` + documento JSON versionado, persistentes entre reinicios de proceso/dispositivo. Exportación e importación con confirmación mediante SAF.
- Transición de pantalla de inicio sutil, equilibrada o desactivada. Sin red, sin publicidad y sin root.

## Funciones aún NO desarrolladas

- Los **17 temas restantes** y fidelidad fotográfica exacta a las tres referencias previas (las imágenes de referencia originales no se adjuntan al proyecto).
- Editor gráfico por capas, drag & drop libre, duplicar capas y deshacer/rehacer.
- 30 widgets propios dinámicos, sincronización climática, integración con calendario, panel multimedia avanzado.
- Icon Studio con paquetes externos, texturas de cristal, personalización individual de etiquetas, fondos dinámicos y motor espacial avanzado.
- Automatizaciones horarias y reglas condicionales, Room, DataStore y migración a Jetpack Compose.
- Pruebas instrumentadas, accesibilidad avanzada, rendimiento, perfiles Samsung y validación de estabilidad en Android 17.

**En ningún caso** el prototipo intercepta One UI, pantalla de bloqueo, AOD, barra de estado o panel rápido.

## Construir APK con GitHub Actions desde el Galaxy S26 Ultra

1. Descomprime este ZIP y sube **el contenido de la carpeta raíz** a un repositorio GitHub nuevo (o integra manualmente en tu repositorio original sin sobrescribirlo). Debes conservar la carpeta `.github/workflows`.
2. Abre tu repositorio en GitHub desde el navegador, entra a **Actions → Compilar APK Android → Run workflow**.
3. Cuando el flujo termine en verde, abre la ejecución y descarga el artefacto **Ultra-Launcher-Studio-Pro-2-APK**.
4. En el teléfono, **extrae el ZIP del artefacto** y abre `app-debug.apk` para instalarlo. Permite la instalación desde la fuente que usas únicamente si confías en el archivo.
5. Abre Ultra Launcher Studio Pro. Para que realmente reemplace tu pantalla de inicio: **☰ → Elegir como inicio predeterminado**; confirma la solicitud de Android.
6. Para regresar a Samsung: **☰ → Volver a One UI Home** y selecciona **One UI Home** en los ajustes de la aplicación de inicio.

**Nota:** La compilación de depuración es una APK de pruebas firmada con clave debug, no una versión de producción ni una versión publicada en Google Play. Cada ejecución de GitHub Actions puede usar una clave debug distinta; para actualizar una instalación anterior sin desinstalar necesitas firma estable de release.

## Estructura

```text
app/src/main/AndroidManifest.xml      Registro HOME y visibilidad específica
app/src/main/java/.../data/           Catálogo de apps, estado, temas
app/src/main/java/.../ui/             Launcher nativo, widgets y editor rápido
app/src/main/assets/themes/           Configuración JSON de tres perfiles
app/src/main/res/drawable-nodpi/      Tres fondos abstractos incluidos
.github/workflows/build-apk.yml      Compilación remota + artefacto APK
```

## Comprobación posterior a la compilación

Se debe probar en un teléfono real que: Android permita elegir el launcher; que Inicio abra Ultra Launcher; que inicie todas las apps compatibles; que el botón Atrás no cierre el HOME; que cambiar tema persista; que los permisos de fotografías se conserven; que el widget externo muestre contenido auténtico y no rompa al rotar; y que One UI Home pueda restablecerse.

## Integración sin pérdida de avances

No se recibió repositorio ni código existente de Ultra Launcher, por lo que **este proyecto se entrega aislado**. No se modifica ninguna aplicación anterior ni se reutiliza su package name. Al aportar el proyecto original se podrán integrar los módulos mediante comparación y migraciones versionadas, sin borrar configuración existente.

## Ruta más sencilla desde un teléfono, subiendo solo un ZIP

También se entrega por separado **`COMPILAR_DESDE_ZIP_GITHUB.yml`**. Puedes subir **`ULTRA_LAUNCHER_STUDIO_PRO_2.0_SOURCE.zip`** entero a la raíz de un repositorio GitHub nuevo, sin extraerlo. En GitHub, usa **Add file → Create new file** y escribe el nombre `.github/workflows/compilar-ultra-launcher.yml`, pegando dentro el texto de `COMPILAR_DESDE_ZIP_GITHUB.yml`. Guarda el archivo, luego en **Actions → Ultra Launcher desde ZIP → Run workflow**. El propio workflow extrae el proyecto y produce el artefacto instalable si la compilación tiene éxito. No es necesario usar simultáneamente las dos rutas.
