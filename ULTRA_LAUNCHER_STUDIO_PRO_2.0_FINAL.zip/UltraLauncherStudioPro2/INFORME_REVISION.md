# Informe de revisión — 24 de octubre de 2026

## Procedencia y conservación

El archivo /mnt/data no está montado en este equipo Windows. Se encontró el ZIP
ULTRA_LAUNCHER_STUDIO_PRO_2.0_SOURCE.zip en Descargas del usuario (389179 bytes).
Se extrajo una copia de trabajo, sin modificar el ZIP de origen.
La lectura del chat anterior devolvió los requisitos, pero ningún adjunto descargable.
No se localizó COMPILAR_DESDE_ZIP_GITHUB.yml: se creó una alternativa nueva.
Todos los archivos originales permanecen en el proyecto; README_ORIGINAL.md guarda
la documentación anterior. Se mantienen package name, datos y tres temas.

## Cambios

- Gradle Wrapper oficial 8.11.1 completo y SHA-256 de distribución fijado.
- Se mantiene AGP 8.9.2 / Kotlin 2.0.21 / SDK 35 / JDK 17.
- Versión incrementada a 2.0.0-alpha2, versionCode 2.
- ScrollView usa isFillViewport, propiedad Kotlin correspondiente al getter Java.
- Insets protegidos por nivel API: Android 10 no ejecuta APIs de Android 11.
- Márgenes laterales consideran barras y recorte de pantalla en APIs compatibles.
- Atrás usa también callback de Android 13+; nuevo intento HOME regresa al escritorio.
- Selección de fondo/widget conserva los campos pendientes al recrear Activity.
- Binding de widget evita solicitar de nuevo uno ya enlazado por el selector.
- Exportación elimina IDs locales de widgets; importación conserva bindings locales
  y descarta IDs externos. No se copian fotos ni autorizaciones de URI.
- Workflow de fuentes usa Wrapper, assembleDebug y lintDebug; falla si falta APK,
  publica informes y limita duración y retención. Workflow alternativo extrae el ZIP
  FINAL con ruta explícita. Solo requiere lectura del repositorio.
- Documentación corregida: dock automático, tres temas, Views/SharedPreferences,
  funciones pendientes, pasos exactos, claves de firma y comprobaciones Samsung.

## Verificaciones realizadas

- Tres tests originales test_structure.py: OK (estructura HOME, temas y workflow).
- Intento gradlew.bat --version: FALLÓ antes de ejecutar Gradle; JAVA_HOME no definido
  y comando java no disponible. No se detectó SDK Android en rutas habituales.
- XML y JSON se revisan al empaquetar; ZIP se comprueba por CRC e inventario.
- No se ejecutó compilador Kotlin, Android lint, Android Studio ni GitHub Actions.
- No se instaló ni probó en teléfono/emulador. No hay APK ni firma release entregada.
- No se realizó validación semántica de YAML con un parser; no estaba instalado.

## Límites y próximos controles

La revisión del código no demuestra compilación ni comportamiento en Samsung.
Ejecutar primero el workflow. Después instalar y comprobar HOME, abrir apps,
Atrás/Inicio, temas, búsqueda, carpetas, foto, widgets, exportación/importación,
recreación, reinicio, modos de navegación y regreso a One UI.
El inicio puede saturarse al agregar muchos elementos; no se añadió un editor
adaptativo ni se declara resuelto ese límite. No se añadieron los 17 temas pendientes,
los 30 widgets propios o el estudio avanzado. El selector de widgets depende del
sistema/proveedor y requiere validación real. Si el proceso muere antes de guardar
estado, todavía puede quedar un ID de widget reservado sin recuperar.

## Referencias consultadas

- https://developer.android.com/build/releases/agp-8-9-0-release-notes
- https://developer.android.com/develop/ui/views/appwidgets/host
- https://docs.github.com/en/actions/concepts/workflows-and-actions/workflow-artifacts
- https://developer.android.com/studio
- Wrapper: https://github.com/gradle/gradle/tree/v8.11.1

## Corrección posterior — fallo real de GitHub Actions

El usuario mostró una ejecución que falla en setup-android@v3 con
`Warning: Failed to find package 'tools'`. No llegó a compilar Kotlin.
Se añadió `with: packages: 'platform-tools'` al preparador Android en ambos
workflows. API 35 y Build Tools 35.0.0 siguen instalándose en el paso siguiente.
La corrección evita pedir el paquete tools retirado. Pendiente de nueva ejecución
remota; no se declara una APK compilada. El ZIP y YAML locales se actualizaron.

## Resultado remoto aportado por el usuario y corrección de lint

El registro completo de GitHub muestra compileDebugKotlin, packageDebug y
assembleDebug completados, seguido de lintDebug FAILED (1 error, 9 warnings).
El único error informado es ProtectedPermissions en BIND_APPWIDGET. La APK se
empaquetó en el runner, pero el workflow falló antes de publicarla. No se dispone
localmente de esa APK ni se ha probado en teléfono.

Se mantiene BIND_APPWIDGET conforme al contrato oficial de AppWidgetHost y se
suprime únicamente ProtectedPermissions en ese elemento mediante tools:ignore.
El código conserva bindAppWidgetIdIfAllowed y ACTION_APPWIDGET_BIND para obtener
consentimiento. No se desactiva lint, no se crea baseline ni se otorgan privilegios
de sistema. Pendiente ejecutar de nuevo lint con este Manifest corregido.
https://developer.android.com/develop/ui/views/appwidgets/host
