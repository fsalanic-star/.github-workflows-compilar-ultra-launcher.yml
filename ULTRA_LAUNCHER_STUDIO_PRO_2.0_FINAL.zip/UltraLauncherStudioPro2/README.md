# ULTRA LAUNCHER STUDIO PRO 2.0 — entrega revisada

Versión: 2.0.0-alpha2. Android nativo, Kotlin y Android Views; no WebView.
Se conserva el proyecto original, los tres fondos, los temas y sus funciones.
README_ORIGINAL.md conserva las instrucciones previas como referencia histórica.

## Estado de verificación

NO se ha compilado una APK en esta revisión. Se intentó ejecutar el wrapper y falló
porque este equipo no tiene JAVA_HOME ni java disponibles. Tampoco se detectó Android
SDK. No se ejecutaron Actions ni pruebas en Samsung. No se garantiza compilación,
estabilidad o compatibilidad con Galaxy S26 Ultra hasta completar esas pruebas.
Tres pruebas de estructura originales pasaron. Esto NO prueba Kotlin ni Gradle.
Los workflows incluidos solicitan assembleDebug y lintDebug; están pendientes de ejecución.
No hay APK dentro del ZIP y no hay un repositorio remoto publicado por esta entrega.

## Archivos y versiones

- Gradle Wrapper oficial 8.11.1: gradlew, gradlew.bat, gradle/wrapper/*. Incluye JAR.
- Android Gradle Plugin 8.9.2, Kotlin 2.0.21, JDK 17.
- compileSdk/targetSdk 35, minSdk 29; Build Tools 35.0.0.
- .github/workflows/build-apk.yml: compila fuentes extraídas.
- COMPILAR_DESDE_ZIP_GITHUB.yml: alternativa para subir únicamente el ZIP.
- INFORME_REVISION.md: cambios, comprobaciones y límites.
- PLAN_DE_DESARROLLO.md: plan original conservado.

La matriz oficial de AGP 8.9 requiere Gradle 8.11.1 y JDK 17:
https://developer.android.com/build/releases/agp-8-9-0-release-notes

## Ruta A — GitHub Actions desde teléfono o PC, sin extraer fuentes

1. Descarga ULTRA_LAUNCHER_STUDIO_PRO_2.0_FINAL.zip y COMPILAR_DESDE_ZIP_GITHUB.yml
   desde los enlaces de esta entrega. Conserva el nombre exacto del ZIP.
2. Inicia sesión en https://github.com y abre https://github.com/new.
3. Crea un repositorio, por ejemplo ultra-launcher-studio, con README y rama main.
   Puede ser privado si tu cuenta permite Actions. No hace falta subir claves.
4. En Code → Add file → Upload files, sube ULTRA_LAUNCHER_STUDIO_PRO_2.0_FINAL.zip
   a la raíz. Pulsa Commit changes y confirma en main.
5. Abre el YAML descargado con un editor de texto y copia TODO su contenido.
6. En el repositorio pulsa Add file → Create new file. Escribe exactamente:
   .github/workflows/compilar-ultra-launcher.yml
7. Pega el YAML y guarda con Commit changes en main. No lo subas como .txt.
8. En Actions habilita los workflows si GitHub lo solicita. Selecciona
   Ultra Launcher desde ZIP → Run workflow → Branch: main → Run workflow.
9. Abre la ejecución y espera a que termine. Solo una ejecución verde confirma
   que esa revisión compiló y pasó las verificaciones configuradas.
10. En la parte inferior, Artifacts → Ultra-Launcher-Studio-Pro-2-APK.
    Descarga el artefacto antes de 14 días y extráelo: dentro estará app-debug.apk.
11. Si falla, abre el paso rojo y consulta su registro. Descarga informes-android
    si existe. Si faltan archivos del APK, el workflow falla explícitamente.
    Comparte el registro completo; no interpretes una ejecución roja como APK lista.

Este workflow espera el ZIP FINAL, no el antiguo SOURCE.zip. El workflow interno
incluido en el ZIP no se ejecuta automáticamente en esta ruta. No necesitas activar
las dos rutas de GitHub a la vez. El YAML separado fue recreado: no se encontró el anterior.

Documentación oficial de artefactos:
https://docs.github.com/en/actions/concepts/workflows-and-actions/workflow-artifacts

## Ruta B — GitHub Actions con fuentes extraídas

1. Extrae el ZIP; abre UltraLauncherStudioPro2. Esa es la raíz del proyecto.
2. Sube su CONTENIDO a la raíz de main, incluyendo la carpeta oculta .github.
   Deben quedar app/, gradle/, gradlew y settings.gradle.kts directamente en la raíz
   del repositorio, no debajo de UltraLauncherStudioPro2/.
3. Para subir desde PC con Git instalado, abre una terminal en esa carpeta:

   git init -b main
   git add .
   git commit -m "Entrega revisada Ultra Launcher 2"
   git remote add origin https://github.com/TU_USUARIO/TU_REPOSITORIO.git
   git push -u origin main

   Sustituye TU_USUARIO y TU_REPOSITORIO. Crea para esta ruta un repositorio vacío
   sin README remoto para evitar conflicto inicial. No ejecutes estos pasos sobre
   otro repositorio existente: integra los cambios mediante comparación.
4. Ve a Actions → Compilar APK Android → Run workflow. También se inicia al subir a main.
5. Descarga y extrae el artefacto igual que en los pasos 9–11 de la ruta A.

## Ruta C — Android Studio en PC

1. Instala Android Studio desde https://developer.android.com/studio.
   Usa una versión compatible con AGP 8.9.2; conserva las versiones del proyecto
   durante la primera compilación para no mezclar una migración con la revisión.
2. Extrae el ZIP en una carpeta local, por ejemplo C:\Android\UltraLauncherStudioPro2.
3. Android Studio → Open → selecciona la carpeta que contiene settings.gradle.kts.
   Acepta abrir el proyecto y permite la sincronización de Gradle.
4. Settings → Build, Execution, Deployment → Build Tools → Gradle:
   selecciona el Wrapper del proyecto y un Gradle JDK 17 instalado.
   Si el JDK incluido no es 17, utiliza Download JDK y elige 17.
5. Tools → SDK Manager → instala Android SDK Platform 35 y, en SDK Tools con
   Show Package Details, Android SDK Build-Tools 35.0.0 y Platform-Tools.
   Acepta las licencias. Android Studio configura local.properties localmente;
   no lo subas a GitHub. Se necesita Internet para descargar dependencias.
6. File → Sync Project with Gradle Files. Espera a que termine sin errores.
7. Abre Terminal dentro de Android Studio, en la raíz del proyecto, y ejecuta:

   Windows PowerShell: .\gradlew.bat :app:assembleDebug :app:lintDebug --stacktrace
   macOS/Linux: bash ./gradlew :app:assembleDebug :app:lintDebug --stacktrace

8. Solo si termina correctamente, toma app/build/outputs/apk/debug/app-debug.apk.
   El informe de lint se guarda en app/build/reports/lint-results-debug.html.
9. También puedes conectar el teléfono por USB, habilitar Opciones de desarrollador
   y Depuración USB, aceptar la autorización del PC y pulsar Run en Android Studio.

No necesitas Gradle global. El Wrapper incluido descarga la versión fijada y verifica
el SHA-256 de la distribución. No necesitas NDK para este proyecto sin código nativo C/C++.

## Instalar y activar en Samsung

1. Copia app-debug.apk al teléfono o descarga el artefacto de GitHub y extráelo.
2. Abre la APK en Mis archivos. Si Android lo pide, autoriza instalar aplicaciones
   desconocidas para esa fuente. Si una política del equipo o Bloqueador automático
   de Samsung impide instalar, revisa el aviso y los ajustes oficiales del teléfono.
3. Instala y abre Ultra Launcher Studio Pro.
4. Menú ☰ → Elegir como inicio predeterminado → confirma la elección de Android.
5. Pulsa Inicio. Comprueba que aparece Ultra Launcher y que abre aplicaciones reales.
6. Para regresar: ☰ → Volver a One UI Home → selecciona One UI Home en los ajustes.
   Alternativa: Ajustes → Aplicaciones → Elegir aplicaciones predeterminadas →
   Aplicación de inicio → One UI Home. Los nombres pueden variar con One UI.
7. Prueba los tres temas, cajón/búsqueda, carpetas, escritorios, fondo propio y widget.
8. Exporta el perfil; cierra y vuelve a abrir; después reinicia y comprueba persistencia.
9. Comprueba navegación por gestos y botones, rotación, texto grande y vuelta a One UI.

La APK debug sirve para pruebas, no es una publicación de producción. Distintas
máquinas/ejecuciones pueden firmar con claves debug diferentes: una actualización
puede ser rechazada por firma incompatible. Exporta antes de desinstalar: desinstalar
borra datos. Para actualizaciones estables usa Android Studio → Build → Generate
Signed App Bundle or APK → APK, crea y conserva tu keystore y usa SIEMPRE esa clave.
No se incluyen claves privadas ni se ha configurado firma release remota.

## Disponible en código, pendiente de validación real

- HOME, solicitud RoleManager, apertura de apps MAIN/LAUNCHER del perfil actual.
- Cajón con búsqueda; favoritos; entre 1 y 5 escritorios; carpetas.
- Dock automático de cuatro apps: todavía NO tiene editor de selección propio.
- Tres temas independientes y fondos incluidos: Coastal, Welcome, Artistic.
- Vista previa, aplicar, título, tamaño de reloj y fotografía propia por tema.
- Hora, fecha y batería reales; clima muestra que falta proveedor.
- Un widget externo por tema mediante AppWidgetHost, selector y autorización del sistema.
- Preferencias locales SharedPreferences/JSON, exportar/importar y transiciones básicas.
- Las fotos conservan URI locales: exportar NO copia imágenes ni permisos a otro teléfono.
- Los IDs de widgets no se exportan; en otra instalación hay que agregarlos de nuevo.
- Los accesos son a actividades de apps: no son shortcuts profundos/LauncherApps completos.

## Pendiente

17 temas adicionales, editor por capas/arrastrar/deshacer, 30 widgets propios,
proveedor climático, calendario y música, Icon Studio completo, dock editable,
automatizaciones, compositor avanzado de fondos, Compose/Room/DataStore,
perfiles de trabajo y shortcuts avanzados, accesibilidad/rendimiento y pruebas reales.
La disposición de inicio aún puede saturarse con muchos iconos/carpetas/widgets;
no se ha validado con pantallas pequeñas, rotación o fuente grande.
No modifica bloqueo, AOD, panel rápido ni componentes protegidos de One UI.
No se afirma que los diez criterios de aceptación estén completados.
